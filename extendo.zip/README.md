# Tab Volume Controller
firefox extension - manifest 3, chrome storage api, slider goes beyond max keep at low and saves per host
